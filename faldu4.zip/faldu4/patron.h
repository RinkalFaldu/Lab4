//---------------------------------------------------------------------------
// patron class:  Class representing a patron registered with the library

// Implementation and assumptions:
// -- Assumes Item class and its derived classes have been properly 
// implemented
//--Patron Id will be listed after the action they perform
//--Patron name will be listed after Id

#ifndef PATRON_H_
#define PATRON_H_

#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <list>
#include <vector>

using namespace std;

class TransactionFactory;
class Transaction;
class Objects;
class Patron {
public:
    Patron();
    Patron(string, string, int);
    ~Patron();
    string getFirstName() const;
    string getLastName() const;
    int getID() const;

    void setFirstName(string);
    void setLastName(string);
    bool setID(int);

    void setData(istream& file);
    void printHistory();           // print history of required patron 

    void addToHistory(Objects*, char);// add transaction to patron history 
    void addToBorrowList(Objects*); // add book 
    void removeFromBorrowList(Objects*);    // remove book 
    // Checks to see if given book is in patron's list of currently 
    // borrow books
    bool inCurrentBooks(const Objects&);


private:
    string first;        // first name from patron       
    string last;         // last name from patron 
    int patronID;         // patron id 
    vector<Transaction*> transactions;      // transaction vectro 
    vector<Objects*> borrowlist;             // borrowlist of books 
    TransactionFactory* transFactory;        // transaction factory vector 
};
#endif