#include "bintree.h"
#include "fiction.h"
#include "children.h"
#include "periodical.h"
#include <iostream>
#include <iomanip>
using namespace std;

//----------------------------------------------------------------------------
// Default constructor
BinTree::BinTree() {
	root = nullptr;
}

//---------------------------------------------------------------------------
// Destructor
BinTree::~BinTree() {
	deleteTree();
}

//---------------------------------------------------------------------------
// isEmpty
bool BinTree::isEmpty() const {
	return root == nullptr;
}

//---------------------------------------------------------------------------
// makeEmpty
void BinTree::deleteTree() {
	deleteTreeHelper(root);
}

void BinTree::deleteTreeHelper(Node*& subtree)
{
	if (subtree != NULL) {
		// recursively traverse the left and right subtree until it hits NULL
		deleteTreeHelper(subtree->left);
		deleteTreeHelper(subtree->right);

		// free the data and set the pointer to null 
		delete subtree->data;
		subtree->data = NULL;

		// free the subtree node and set the pointer to null
		delete subtree;
		subtree = NULL;
	}
}



//---------------------------------------------------------------------------
// insert
bool BinTree::insert(Objects* dataptr)
{
	Node* ptr = new Node; // created new node to insert book in tree 
	ptr->data = dataptr;
	ptr->left = ptr->right = nullptr;
	if (isEmpty()) {
		root = ptr;
	}
	else {
		Node* current = root;
		bool inserted = false;
		// accounts for duplicates; inserts either right or left of tree
		while (!inserted) {
			if (*ptr->data == *current->data) {
				delete ptr;
				ptr = NULL;
				return false;
			}
			// insert to the left, otherwise move left one
			else if (*ptr->data < *current->data) {
				if (current->left == nullptr) {
					current->left = ptr;
					inserted = true;
				}
				else
					current = current->left;
			}
			// insert to the right, otherwise move right one
			else {
				if (current->right == nullptr) {
					current->right = ptr;
					inserted = true;
				}
				else
					current = current->right;
			}
		}
	}
	return true;
}

//---------------------------------------------------------------------------
// retrieve
bool BinTree::retrieve(const Objects& target, Objects*& storage) const
{
	// empty tree, cannot find target
	if (isEmpty()) {
		storage = NULL;
		return false;
	}
	else {
		// tree walker, will traverse the tree to find target
		Node* current = root;

		// traverse the tree until target is found or end of tree
		while (current != NULL) {
			// target was found, return true and object gets assigned the value
			if (target == *current->data) {
				storage = current->data;
				return true;
			}
			// target is on the left side or not in tree
			else if (target < *current->data) {
				if (current->left != NULL)
					current = current->left;
				else
					break;
			}
			// target is on the right side or not in tree
			else {
				if (current->right != NULL)
					current = current->right;
				else
					break;
			}
		}
		// target was not in tree
		return false;
	}
}

//---------------------------------------------------------------------------
// print 
// print header and call make call to the function that print books
void BinTree::print(char ch)
{
	if (ch == 'F' || ch == 'C') {
		cout << left << setw(10) << "AVAIL" << setw(25) << "Author"
			<< setw(37) << "Title" << setw(9) << "Year" << endl;
		this->inOrderPrint();
	}
	else if (ch == 'P') {
		cout << left << setw(10) << "AVAIL" << setw(29) << "Title"
			<< setw(21) << "Month" << setw(7) << "Year" << endl;
		this->inOrderPrint();
	}
}

//---------------------------------------------------------------------------
// inOrderPrint
void BinTree::inOrderPrint() const {
	inOrderHelper(root);
}

//---------------------------------------------------------------------------
// inorderHelper
// prints books for display transaction
void BinTree::inOrderHelper(Node* current) const
{
	if (current == nullptr)
	{
		return;
	}
	inOrderHelper(current->left);
	if (current->data->getFormat() == 'F') {
		const Fiction& aFiction = static_cast<const Fiction&>(*current->data);
		string name = aFiction.getLastName() + " " + aFiction.getFirstName();
		cout << left << setw(10) << aFiction.getNumCopies() << setw(25)
			<< name << setw(37) << aFiction.getTitle() << setw(10)
			<< aFiction.getYear() << endl;
	}
	else if (current->data->getFormat() == 'C') {
		const Children& aChildren = static_cast<const Children&>(*current->data);
		string name = aChildren.getLastName() + " " + aChildren.getFirstName();
		cout << left << setw(10) << aChildren.getNumCopies() << setw(25)
			<< name << setw(37) << aChildren.getTitle() << setw(10)
			<< aChildren.getYear() << endl;
	}
	else if (current->data->getFormat() == 'P') {
		const Periodical& aPeriodical = static_cast<const Periodical&>
			(*current->data);
		cout << left << setw(10) << aPeriodical.getNumCopies() << setw(25)
			<< aPeriodical.getTitle() << setw(5) << right << aPeriodical.getMonth()
			<< setw(24) << aPeriodical.getYear() << endl;
	}
	inOrderHelper(current->right);

}
