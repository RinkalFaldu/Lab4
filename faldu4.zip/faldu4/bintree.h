//----------------------------------------------------------------------------
//BinTree class: A binary tree that stores books 
// Implementation and Assumption:
//-- binary tree supports different operation such as insert,
//    retrieve, searching, print books and header
#ifndef BINTREE_H_
#define BINTREE_H_
#include "objects.h"
class BinTree {
public:
    BinTree();     // default constructor 
    ~BinTree();    // destructor   
    bool isEmpty() const;  //is tree empty?     
    void deleteTree();      // make tree empty 
    bool insert(Objects*); // insert nodes 
    bool retrieve(const Objects&, Objects*&) const; // retrieve tree 
    void print(char ch);  // print header of display 
    void inOrderPrint() const;  // print display transaction 

    //private:
    struct Node {
        Objects* data;    // a pointer to the Product object
        Node* left;      // a pointer to the left Node object
        Node* right;    // a pointer to the right Node object
    };
    Node* root;

    void inOrderHelper(Node*) const;      // helpeer of inorderprint 
    void deleteTreeHelper(Node*&);         // helper of makeempty 

};
#endif