#include "fiction.h"
//--------------------------------------------------------------------------
//default destructor 
Fiction::Fiction()
{
}

//--------------------------------------------------------------------------
//destructor
Fiction::~Fiction()
{
}

//--------------------------------------------------------------------------
//getFirstName 
string Fiction::getFirstName() const
{
    return first;
}

//--------------------------------------------------------------------------
//getlatName
string Fiction::getLastName() const
{
    return last;
}

//--------------------------------------------------------------------------
//setFirstName
void Fiction::setFirstName(string newName)
{
    first = newName;
}

//--------------------------------------------------------------------------
//setLastName
void Fiction::setLastName(string newName)
{
    last = newName;
}

//--------------------------------------------------------------------------
//getMonth
int Fiction::getMonth() const
{
    return 0;
}

//--------------------------------------------------------------------------
//create
Objects* Fiction::create() const
{
    return nullptr;
}

//--------------------------------------------------------------------------
//setData
//reads in the file and sets fiction variables accordingly 
bool Fiction::setData(istream& file)
{
    this->bookType = 'F';
    itemFormat = bookType;

    file.get();

    string author;
    file >> author;
    this->last = author;
    file.get();
    string first;
    getline(file, first, ',');
    this->first = first;

    file.get();
    string title;
    getline(file, title, ',');
    this->title = title;

    file.get();
    int year;
    file >> year;
    this->year = year;

    return true;
}

//--------------------------------------------------------------------------
//setTransactionData 
//reads in the file and sets transaction variables accordingly 
bool Fiction::setTransactionData(istream& file)
{
    string firstName;
    string lastName;
    string title;
    file >> lastName;
    this->last = lastName;
    file.get();
    getline(file, firstName, ',');
    this->first = firstName;
    file.get();
    getline(file, title, ',');
    this->setTitle(title);
    this->setFormat('F');
    return true;
}

//--------------------------------------------------------------------------
//print
//used for display history 
void Fiction::print() const
{
    cout << " " << title << "   " << last << " " << first << "    " << year;
}
//--------------------------------------------------------------------------
//operator ==
//determines if two fiction books are equal using title, first and last name
bool Fiction::operator==(const Objects& rhs) const
{
    if (this->bookType == rhs.getFormat()) {
        const Fiction& aFiction = static_cast<const Fiction&>(rhs);
        if (this->title == aFiction.title) {
            if (this->first == aFiction.first) {
                if (this->last == aFiction.last) {
                    return true;
                }
            }
        }
    }
    return false;
}

//--------------------------------------------------------------------------
//operator !=
bool Fiction::operator!=(const Objects& rhs) const
{
    return !(*this == rhs);
}

//--------------------------------------------------------------------------
//operator <
bool Fiction::operator<(const Objects& rhs) const
{
    if (this->bookType == rhs.getFormat()) {
        const Fiction& aFiction = static_cast<const Fiction&>(rhs);
        if (this->last != aFiction.last) {
            if (this->last < aFiction.last) {
                return true;
            }
        }
        else if (this->first != aFiction.first) {
            if (this->first < aFiction.first) {
                return true;
            }
        }
        else {
            if (this->title != aFiction.title) {
                if (this->title < aFiction.title) {
                    return true;
                }
            }
        }
    }
    return false;
}

//--------------------------------------------------------------------------
//operator >
bool Fiction::operator>(const Objects& rhs) const
{
    if (this->bookType == rhs.getFormat()) {
        const Fiction& aFiction = static_cast<const Fiction&>(rhs);
        if (this->last != aFiction.last) {
            if (this->last > aFiction.last) {
                return true;
            }
        }
        else if (this->first != aFiction.first) {
            if (this->first > aFiction.first) {
                return true;
            }
        }
        else {
            if (this->title != aFiction.title) {
                if (this->title > aFiction.title) {
                    return true;
                }
            }
        }
    }
    return false;
}