
//transactionfactory class:
// Derived class of Factory class for returning transaction objects
// Implementation and assumptions:  
//-- Requires a valid character to be added
//-- Requires the istream to be properly formatted
//---------------------------------------------------------------------------

#ifndef TRANSACTIONFACTORY_H
#define TRANSACTIONFACTORY_H

#include "transaction.h"
#include "checkout.h"
#include "return.h"
#include "display.h"
#include "transactionhistory.h"

class Transaction;
class TransactionFactory {
public:
    TransactionFactory();
    virtual ~TransactionFactory();
    //Creates the necassary transaction objects
    Transaction* createObject(char ch) const;
protected:
    Transaction* objFactory[26];

};

#endif