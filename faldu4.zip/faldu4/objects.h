//Objects class: Pure virtual class representing a general product, 
//               controls distribution
#ifndef OBJECTS_H_
#define OBJECTS_H_

#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
using namespace std;

class Objects {
    friend ostream& operator<<(ostream&, const Objects&);
public:
    Objects();     // default constructor 
    virtual ~Objects();   // virtual destructor 

    virtual string getTitle() const;
    virtual bool inStock() const;                 // does book in stock?       
    virtual int getYear() const = 0;
    virtual char getFormat() const = 0;

    virtual void setYear(int) = 0;
    virtual void setFormat(char ch) = 0;
    virtual int getNumCopies() const;

    virtual string getLastName() const = 0;
    virtual string getFirstName() const = 0;
    virtual int getMonth() const = 0;

    virtual void setNumCopies(int);

    virtual Objects* create() const = 0; // create instance of item 
    virtual bool setData(istream&) = 0;
    virtual bool setTransactionData(istream&) = 0;
    virtual void print() const;

    virtual bool operator==(const Objects&) const = 0;
    virtual bool operator!=(const Objects&) const = 0;
    virtual bool operator<(const Objects&) const = 0;
    virtual bool operator>(const Objects&) const = 0;

protected:
    char itemFormat;          // item formate H 
    string title;             // title of book 
    int copies;               // number of copes 
};

#endif