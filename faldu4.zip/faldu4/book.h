//---------------------------------------------------------------------------
// Book class: derives class of Objects  
//-- (Virtual) Getters/Setters for all data members and pure virtual
//      getters/setters for use in derived classes
#ifndef BOOK_H
#define BOOK_H

#include "objects.h"
class Book : public Objects
{
public:
    Book();            //default constructor 
    virtual ~Book();   // destructor 
    virtual int getYear() const;  // get year 
    virtual char getFormat() const;  // get book type 

    virtual void setYear(int);       // set year 
    virtual void setFormat(char);    // set book type 

    virtual void setTitle(string);   // set title 

    virtual string getLastName() const = 0;    // get last name of author  
    virtual string getFirstName() const = 0;   // get first name of author 
    virtual int getMonth() const = 0;          // get month of book    

    virtual Objects* create() const = 0;
    virtual bool setData(istream&) = 0;        // set data of books 
    virtual bool setTransactionData(istream&) = 0; // set transaction data 
    virtual void print() const;

    //-------------------------------------------------------------------
    // Operator overloads (pure virtual)
    virtual bool operator==(const Objects&) const = 0;
    virtual bool operator!=(const Objects&) const = 0;
    virtual bool operator<(const Objects&) const = 0;
    virtual bool operator>(const Objects&) const = 0;

protected:
    // further data members for book items
    int year;                           // book year 
    char bookType;                     // book types 
};

#endif