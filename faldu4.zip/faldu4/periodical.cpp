#include "periodical.h"
#include <iomanip>
//--------------------------------------------------------------------------
//default constructor 
Periodical::Periodical()
{
    month = 0;
}

//--------------------------------------------------------------------------
//destructor
Periodical::~Periodical()
{
}

//--------------------------------------------------------------------------
//getMonth
int Periodical::getMonth() const
{
    return month;
}

//--------------------------------------------------------------------------
//setMonth 
void Periodical::setMonth(int date)
{
    month = date;
}

//--------------------------------------------------------------------------
//getLastName
string Periodical::getLastName() const
{
    return "";
}

//--------------------------------------------------------------------------
//getFirstName
string Periodical::getFirstName() const
{
    return "";
}

//--------------------------------------------------------------------------
//create
Objects* Periodical::create() const
{
    return nullptr;
}

//--------------------------------------------------------------------------
//setData
//reads in the file and sets fiction variables accordingly 
bool Periodical::setData(istream& file)
{
    file.get();
    string title;
    getline(file, title, ',');
    file.get();

    int month;
    file >> month;
    this->setMonth(month);

    int year;
    file >> year;
    this->setYear(year);


    this->title = title;
    this->bookType = 'P';
    this->copies = 1;
    itemFormat = bookType;

    return true;
}

//--------------------------------------------------------------------------
//setTransactionData 
//reads in the file and sets transaction variables accordingly 
bool Periodical::setTransactionData(istream& file)
{
    string firstName;
    string lastName;
    string title;
    int month;
    int year;
    file >> year;
    this->setYear(year);
    file.get();
    file >> month;
    this->setMonth(month);
    file.get();
    getline(file, title, ',');
    this->setTitle(title);
    this->setFormat('P');
    return true;
}

//--------------------------------------------------------------------------
//print
//used for display history 
void Periodical::print() const
{
    cout << " " << month << " " << year << " " << title;
}

//--------------------------------------------------------------------------
//operator ==
bool Periodical::operator==(const Objects& rhs) const
{
    if (this->bookType == rhs.getFormat()) {
        const Periodical& aPeriodical = static_cast<const Periodical&>(rhs);
        if (this->title == aPeriodical.title) {
            if (this->year == aPeriodical.year) {
                if (this->month == aPeriodical.month) {
                    return true;
                }
            }
        }
    }
    return false;
}

//--------------------------------------------------------------------------
//operator !=
bool Periodical::operator!=(const Objects& rhs) const
{
    return !(*this == rhs);
}


//--------------------------------------------------------------------------
//operator <
bool Periodical::operator<(const Objects& rhs) const
{
    if (this->bookType == rhs.getFormat()) {
        const Periodical& aPeriodical = static_cast<const Periodical&>(rhs);
        if (this->year != aPeriodical.year) {
            if (this->year < aPeriodical.year) {
                return true;
            }
        }
        else if (this->month != aPeriodical.month) {
            if (this->month < aPeriodical.month) {
                return true;
            }
        }
        else if (this->title != aPeriodical.title) {
            if (this->title < aPeriodical.title) {
                return true;
            }
        }
    }
    return false;
}

//--------------------------------------------------------------------------
//operator >
bool Periodical::operator>(const Objects& rhs) const
{
    if (this->bookType == rhs.getFormat()) {
        const Periodical& aPeriodical = static_cast<const Periodical&>(rhs);
        if (this->year != aPeriodical.year) {
            if (this->year > aPeriodical.year) {
                return true;
            }
        }
        else if (this->month != aPeriodical.month) {
            if (this->month > aPeriodical.month) {
                return true;
            }
        }
        else if (this->title != aPeriodical.title) {
            if (this->title > aPeriodical.title) {
                return true;
            }
        }
    }
    return false;
}
