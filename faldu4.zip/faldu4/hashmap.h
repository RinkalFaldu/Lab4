//---------------------------------------------------------------------------
// patronhashmap class : use for store all patrons  
//---------------------------------------------------------------------------
// Implementation and assumptions:  
//   -- Hash function computes index of array based  

#ifndef HASHMAP_H
#define HASHMAP_H

#include <list>
#include "patron.h"

const int TABLE_SIZE = 10001; // Prime number for better distribution

class HashMap {
public:
    HashMap();
    ~HashMap();
    void insert(Patron* newPatron);
    bool retrieve(int patronID, Patron*& foundPatron) const;
    void print() const;

private:
    // Array of lists for chaining
    std::list<Patron*> table[TABLE_SIZE];
    int hash(int key) const; // Hash function
};

#endif

