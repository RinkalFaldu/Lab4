#include "library.h"

//--------------------------------------------------------------------------
//Default constructor 
//None
Library::Library()                                     
{
}

//--------------------------------------------------------------------------
//Destructor
//None
Library::~Library()
{

}

//--------------------------------------------------------------------------
//processTransactions
//reads in the file and uses polymorphism to assign variables
void Library::processTransactions(ifstream& file)
{
    for (;;) {
        char code;
        file >> code;
        if (file.eof()) {
            break;
        }
        //creates respective object using the code 
        Transaction* newTransaction =
            transactionFactory.createObject(code);
        if (newTransaction != nullptr) {
            bool success = newTransaction->setData(file);
            if (success) {
                if (!newTransaction->execute(this, books)) {
                }

            }
        }
        else {
            cout << "ERROR: invalid Transaction " << code << endl;
            file.ignore(std::numeric_limits<std::streamsize>::max(),
                '\n');
        }

        delete newTransaction;
        newTransaction = nullptr;
    }
}




//--------------------------------------------------------------------------
//addPatrons
//reads in the file and uses polymorphism to assign variables
void Library::addPatrons(ifstream& file)
{
    for (;;)
    {
        int patronID;
        file >> patronID;
        if (file.eof())
        {
            break;
        }
        Patron* newPatron = new Patron();
        if (!newPatron->setID(patronID))
        {
            file.ignore(std::numeric_limits<std::streamsize>::max(),
                '\n');
            delete newPatron;
            newPatron = nullptr;

        }
        else
        {
            newPatron->setData(file);
            patrons.insert(newPatron);
        }

    }
}

//--------------------------------------------------------------------------
//print
//None
void Library::print(char) const
{
}

//--------------------------------------------------------------------------
//getMap
//returns patronhashmap
HashMap Library::getMap() const
{
    return patrons;
}

//--------------------------------------------------------------------------
//addBooks
//reads in the file and uses polymorphism to assign variables
void Library::addBooks(ifstream& file)
{
    for (;;) {
        char code;
        file >> code;
        if (file.eof()) {
            break;
        }
        //creates respective object using the code 
        Objects* newItem = bookFactory.createObject(code);
        if (newItem != nullptr) {
            newItem->setData(file);
            bool success = books[code - 'A'].insert(newItem);
        }
        else {
            cout << "ERROR: '" << code << "' is not a valid book type"
                << endl;
            string garbage;
            getline(file, garbage);
        }
    }

}
