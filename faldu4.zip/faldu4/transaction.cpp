#include "transaction.h"
//--------------------------------------------------------------------------
//default destructor
Transaction::Transaction()
{
	book = nullptr;
	inTree = false;
	transactionType = 'X';
}

//--------------------------------------------------------------------------
//destructor
Transaction::~Transaction()
{
	delete book;
	book = nullptr;
}

//--------------------------------------------------------------------------
//getTransactionType 
char Transaction::getTransactionType() const
{
	return transactionType;
}

//--------------------------------------------------------------------------
//setTransactionType 
void Transaction::setTransactionType(char ch)
{
	transactionType = ch;
}

//--------------------------------------------------------------------------
//print
void Transaction::print() const
{
}

//--------------------------------------------------------------------------
//getPatron
Patron Transaction::getPatron()
{
	return patron;
}

//--------------------------------------------------------------------------
//getItem 
//returns the item of the current transaction 
Objects* Transaction::getItem()
{
	return book;
}

//--------------------------------------------------------------------------
//setItem 
//returns the item of the current transaction 
bool Transaction::setItem(Objects* theItem)
{
	book = theItem;
	return true;
}


