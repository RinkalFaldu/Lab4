1. Describe (briefly) the state of your program, exactly what works and what
   does not work.

Ans: I believe all the classes work as they should and the output is correct,
 but I have some memory leak in my code I think this memory leak problem 
does not work properly. 


2. List your hash table(s) that you wrote (not STL) - briefly what they are 
used for and file they are found in. (Include any factories that are 
essentially hash tables).

Ans: hash table use for store patrons, and this found in hashmap file 

3. State which file and which function you read the book data, just high-level
 function calls, i.e., how/where it gets into your collections. Just names,
 no explanation.

Ans: I used setData to read book data into different types of such as children
     book, fiction book, periodic book. The function I read the movie data with 
is the setDat in the object class, which its children will take in and sort out by
 itself.The book collections is stored in an hash table of BSTs, and they are
	inserted into the tree as the data4book.txt file gets read in the
	library class, in the addbook(istream&) function.
 

4. State which file and which function you read the command data, high-level function 
calls, i.e., how/where you perform the commands.  Just names, no explanation.

Ans: The function I use to read command data is the setData() function
	which is in the different types transaction.It is performed in
 the processTransaction()function and is located in the library class. 


5. Describe any dirty little secrets (e.g., switch used, or if-else-if, etc.) 
 If you feel they do not violate the open-close design principle, explain.

Ans: I used switch statment in both facory class to create object, I think this 
can violates open close design principle 

6. Describe anything you are particularly proud of . . .

Ans: I am proud of for that I am at least able to get something as output 
and able to write nicer program that can be usefull in real life in library system
