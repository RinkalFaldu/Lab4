//---------------------------------------------------------------------------
// transaction class: stores different types of transaction such as checkout
//                    return, and display history, display  
#ifndef TRANSACTION
#define TRANSACTION

#include <iostream>
#include "objects.h"
#include "patron.h"
#include "bookfactory.h"
#include "bintree.h"

class Library;
using namespace std;

class Transaction
{
public:
    Transaction();
    virtual ~Transaction();

    virtual char getTransactionType() const;
    virtual void setTransactionType(char);

    virtual Transaction* create() const = 0;
    virtual void print() const;

    virtual bool setData(istream&) = 0;
    virtual Patron getPatron();
    virtual Objects* getItem();
    virtual bool setItem(Objects*);

    virtual bool execute(Library* lib, BinTree books[]) = 0;

protected:
    char transactionType;           // transaction type             
    Patron patron;                  // patron 
    Objects* book;                 // pointer to the book 
    bool inTree;                     // tree in book     
    BookFactory makeBooks;           // make book 
};

#endif