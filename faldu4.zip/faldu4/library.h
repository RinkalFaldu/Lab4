
// library class : Management of books and patrons
 // Implementation and assumption:
 //--All data is formatted properly
 //--Keep track of books and patrons
#ifndef LIBRARY_H_
#define LIBRARY_H_

#include "hashmap.h"
#include "bintree.h"
#include "bookfactory.h"
#include "transactionfactory.h"
#include <iomanip>
#include <limits>
class Library
{
public:
    Library();
    ~Library();
    void processTransactions(ifstream&); // processes all transactions
    void addBooks(ifstream&); // adds all books to the library
    void addPatrons(ifstream&); // adds all patrons to library system
    void print(char) const; // prints out entire library
    HashMap getMap() const;        // returns patronhashmap 

private:
    HashMap patrons;//store patrons
    BinTree books[26]; //store genres
    BookFactory bookFactory;//create book objects
    TransactionFactory transactionFactory; //create transaction objects

};
#endif 