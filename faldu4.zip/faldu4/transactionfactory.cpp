#include "transactionfactory.h"

//--------------------------------------------------------------------------
//default destructor
TransactionFactory::TransactionFactory()
{
    for (int i = 0; i < 26; i++) {
        objFactory[i] = nullptr;
    }
}

//--------------------------------------------------------------------------
//destructor
TransactionFactory::~TransactionFactory()
{
    for (int i = 0; i < 26; i++) {
        delete objFactory[i];
        objFactory[i] = nullptr;
    }
}

//--------------------------------------------------------------------------
//createObject
Transaction* TransactionFactory::createObject(char ch) const
{
    switch (ch) {
    case 'R':
        return new Return();
        break;
    case 'C':
        return new Checkout();
        break;
    case 'H':
        return new TransactionHistory();
        break;
    case 'D':
        return new Display();
        break;
    default: //cases which arent checkout or return or display
        return nullptr;
    }
}