#include "display.h"

//--------------------------------------------------------------------------
//default destructor
Display::Display()
{
	book = nullptr;
	inTree = false;
	transactionType = 'D';
}

//--------------------------------------------------------------------------
//destructor
Display::~Display()
{
}


//--------------------------------------------------------------------------
//create
Transaction* Display::create() const
{
	return nullptr;
}

//--------------------------------------------------------------------------
//setData
bool Display::setData(istream&)
{
	return true;
}

//--------------------------------------------------------------------------
//print
void Display::print() const
{
}

//--------------------------------------------------------------------------
//execute
//checksout the desired book and doees all the proper error checks 
bool Display::execute(Library* lib, BinTree books[])
{
	//Prints each book inventory 
	cout << "FICTION BOOKS" << endl;
	books['F' - 'A'].print('F');
	cout << endl << endl;

	cout << "CHILDREN BOOKS" << endl;
	books['C' - 'A'].print('C');
	cout << endl << endl;

	cout << "PERIODICAL BOOKS" << endl;
	books['P' - 'A'].print('P');
	cout << endl << endl;
	return true;
}