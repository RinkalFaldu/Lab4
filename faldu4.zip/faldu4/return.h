//---------------------------------------------------------------------------
// return class: derived class from transaction for check out book 
// Return class Implementation and assumptions:  
//   -- Assumes Patron and Book both exist and are in system. 
#ifndef RETURN_H_
#define RETURN_H_
#include "transaction.h"
#include <limits>
class Library;
class Return : public Transaction
{
public:
    Return();
    ~Return();
    virtual Transaction* create() const;
    virtual bool setData(istream&);
    virtual void print() const;
    virtual bool execute(Library* lib, BinTree books[]);
};

#endif