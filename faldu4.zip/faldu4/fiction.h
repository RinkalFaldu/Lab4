//---------------------------------------------------------------------------
// fiction class : derived class from book to store fiction book 

#ifndef FICTION_H_
#define FICTION_H_
#include "book.h"
class Fiction : public Book
{
public:
    Fiction(); // default constructor 
    virtual ~Fiction(); // destructor 

    string getFirstName() const;
    string getLastName() const;
    void setFirstName(string);
    void setLastName(string);
    int getMonth() const;

    virtual Objects* create() const;
    virtual bool setData(istream&);
    virtual bool setTransactionData(istream&);
    virtual void print() const;

    virtual bool operator==(const Objects&) const;
    virtual bool operator!=(const Objects&) const;
    virtual bool operator<(const Objects&) const;
    virtual bool operator>(const Objects&) const;

protected:
    string name;       // name of author 
    string first;      // first name of author 
    string last;       // last name of author 
};

#endif