#include "hashmap.h" 
#include <iostream>
//---------------------------------------------------------------------------
//constructor 
HashMap::HashMap() {

}

//---------------------------------------------------------------------------
//destructor 
HashMap::~HashMap() {

}

//---------------------------------------------------------------------------
//insert
void HashMap::insert(Patron* newPatron) {
    if (newPatron == nullptr) {
        return; // Safeguard against null pointers
    }
    int index = hash(newPatron->getID());
    // Optional: Check for duplicates before insertion
    for (auto* patron : table[index]) {
        if (patron->getID() == newPatron->getID()) {
            std::cout << "ERROR: Patron ID  " << newPatron->getID()
                << " already exists. " << endl;
            return;
        }
    }
    table[index].push_back(newPatron);
}

//---------------------------------------------------------------------------
//retrieve
bool HashMap::retrieve(int patronID, Patron*& foundPatron) const {
    int index = hash(patronID);
    for (auto* patron : table[index]) {
        if (patron->getID() == patronID) {
            foundPatron = patron;
            return true;
        }
    }
    foundPatron = nullptr;
    return false;
}

//---------------------------------------------------------------------------
//print
void HashMap::print() const {
    for (int i = 0; i < TABLE_SIZE; ++i) {
        if (!table[i].empty()) {
            for (auto* patron : table[i]) {
                std::cout << patron->getID() << " " << patron->getFirstName()
                    << " " << patron->getLastName() << std::endl;
            }
        }
    }
}

//---------------------------------------------------------------------------
//hash
int HashMap::hash(int key) const {
    return key % TABLE_SIZE;
}

