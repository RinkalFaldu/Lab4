//---------------------------------------------------------------------------
// checkout class: derived transaction class for check out 
// Implementation and assumptions:  
//   -- Assumed Patron and Book both exist and are in system.

#ifndef CHECKOUT_H
#define CHECKOUT_H
#include "transaction.h"
#include <limits>
class Library;
class Checkout : public Transaction {
public:
    Checkout();    // default constructor 
    ~Checkout();   // destructor 
    virtual Transaction* create() const;
    virtual bool setData(istream&);   // set data of checkout 
    virtual void print() const;       // use for print transaction history 
    virtual bool execute(Library* lib, BinTree books[]);// perform transaction 
};

#endif