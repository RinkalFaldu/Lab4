//---------------------------------------------------------------------------
// children class: dervied class from book for children book type 
//  Implementation and assumptions:  
//  --children book sorted by title, then author. No other data used for sorting, 
//      and criteria uniquely identifies each childrens book.

#ifndef CHILDRENS_H
#define CHILDRENS_H
#include "book.h"

class Children : public Book
{
public:
    Children();   // default constructor 
    virtual ~Children();    // destructor 
    virtual int getYear() const;
    virtual char getFormat() const;
    virtual void setYear(int);
    virtual void setFormat(char);

    virtual string getFirstName() const;
    virtual string getLastName() const;
    virtual void setFirstName(string);
    virtual void setLastName(string);
    virtual int getMonth() const;

    // For use with bookfactory class - creates and returns
    // an instance of the ChildrensBook class 
    virtual Objects* create() const;
    virtual bool setData(istream&);  // reads data file 

    virtual bool setTransactionData(istream&);
    virtual void print() const; // this function use with output overload

    virtual bool operator==(const Objects&) const;
    virtual bool operator!=(const Objects&) const;
    virtual bool operator<(const Objects&) const;
    virtual bool operator>(const Objects&) const;

protected:
    string name;    // authore name 
    string first;   // authore first name 
    string last;    // authore last name 
};

#endif