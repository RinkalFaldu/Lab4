#include "book.h"
//---------------------------------------------------------------------------
// Default constructor
Book::Book()
{
	bookType = 'X';
	year = 0;
}

//---------------------------------------------------------------------------
// Destructor
Book::~Book()
{
}

//---------------------------------------------------------------------------
// getYear
int Book::getYear() const
{
	return year;
}

//---------------------------------------------------------------------------
// getFormat
char Book::getFormat() const
{
	return bookType;
}

//---------------------------------------------------------------------------
// setYear
void Book::setYear(int date)
{
	year = date;
}

//---------------------------------------------------------------------------
// setFormat
void Book::setFormat(char ch)
{
	bookType = ch;
	itemFormat = ch;
}

//---------------------------------------------------------------------------
// setTitle
void Book::setTitle(string newTitle)
{
	title = newTitle;
}
void Book::print() const
{

}
