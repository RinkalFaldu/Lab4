#include "transactionhistory.h"
#include "library.h"
#include "objects.h"
#include "patron.h"
#include "bintree.h"
//---------------------------------------------------------------------------
//Default constructor  
TransactionHistory::TransactionHistory()
{
    book = nullptr;
    inTree = false;
    transactionType = 'H';
}

//---------------------------------------------------------------------------
//Destructor
TransactionHistory::~TransactionHistory()
{
}


//---------------------------------------------------------------------------
//create
Transaction* TransactionHistory::create() const
{
    return nullptr;
}

//---------------------------------------------------------------------------
//setData
bool TransactionHistory::setData(istream& file)
{
    file.get();
    int patronID;
    file >> patronID;
    //Checks if ID is 4 digits 
    if (patronID < 0 || patronID > 9999) {
        cout << "ERROR: patron ID " << patronID << " does not exist "
            << endl;
        return false;
    }
    this->patron.setID(patronID);
    return true;
}

//---------------------------------------------------------------------------
//print
void TransactionHistory::print() const
{
}

//---------------------------------------------------------------------------
//execute 
bool TransactionHistory::execute(Library* lib, BinTree books[])
{
    Patron* thePatron;
    Patron patron = this->getPatron();
    //Checks if patron exists 
    if (lib->getMap().retrieve(patron.getID(), thePatron)) {
        cout << endl;
        cout << thePatron->getID() << " " << thePatron->getLastName()
            << ", " << thePatron->getFirstName() << ":" << endl;
        //Prints transacion history 
        thePatron->printHistory();
        cout << endl << endl;
        return true;
    }
    else {
        cout << "ERROR: patron ID " << patron.getID() << " does not exist. "
            << endl;
        return false;
    }
}