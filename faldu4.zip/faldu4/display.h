//---------------------------------------------------------------------------
// display class : derived transaction class for print different types 
// of book ( transaction types is D)
//  Implementation and assumptions:  
//   -- Assumed Patron exist and is in system.

#ifndef DISPLAY_H
#define DISPLAY_H
#include "transaction.h"

class Library;
class Display : public Transaction
{
public:
    Display();   // default constructor 
    ~Display();  // destructor 
    virtual Transaction* create() const;
    virtual bool setData(istream&);   // set data 
    virtual void print() const;
    virtual bool execute(Library* lib, BinTree books[]);
};

#endif