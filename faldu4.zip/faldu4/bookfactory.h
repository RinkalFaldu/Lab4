//---------------------------------------------------------------------------
// bookfactory class: stores different types of book object.
//---------------------------------------------------------------------------
// Implementation and assumptions:  
//   -- Objects* createObject(char) function returns new Book object, where the
//      type of book is determined by input char ( C, F, P)
//   -- objFactory data member is array of Object*, where each each index maps 
//      to a particular book type. 
//---------------------------------------------------------------------------
#ifndef BOOKFACTORY_H
#define BOOKFACTORY_H

#include "fiction.h"
#include "children.h"
#include "periodical.h"
#include "objects.h"

class BookFactory {
public:
    BookFactory();    // constructor 
    virtual ~BookFactory();    // destructor 
    // createobject based on character of book 
    Objects* createObject(char ch) const;
protected:
    Objects* objFactory[26];   // container for products, hashtable 

};

#endif