#include "bookfactory.h"
//---------------------------------------------------------------------------
// Default constructor
BookFactory::BookFactory() {
    for (int i = 0; i < 26; i++) {      // intialize empty array 
        objFactory[i] = nullptr;
    }
}

//---------------------------------------------------------------------------
// Destructor
BookFactory::~BookFactory() {
    for (int i = 0; i < 26; i++) {
        delete objFactory[i];
        objFactory[i] = nullptr;
    }
}

//---------------------------------------------------------------------------
// createObject 
Objects* BookFactory::createObject(char ch) const
{
    switch (ch) {
    case 'F':
        return new Fiction();
    case 'P':
        return new Periodical();
    case 'C':
        return new Children();
    default:
        return nullptr;

    }

}
