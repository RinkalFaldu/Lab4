#include "patron.h"
#include "transaction.h"
#include "objects.h"
#include "children.h"
#include "fiction.h"
#include "periodical.h"
#include "transactionfactory.h"
//--------------------------------------------------------------------------
//default constructor 
Patron::Patron()
{
    patronID = -1;
    first = " ";
    last = " ";

}

//--------------------------------------------------------------------------
//constructor
Patron::Patron(string theFirst, string theLast, int id)
{
    first = theFirst;
    last = theLast;
    patronID = id;

}

//--------------------------------------------------------------------------
//destructor
Patron::~Patron()
{

}

//--------------------------------------------------------------------------
//getFirstName 
string Patron::getFirstName() const
{
    return first;
}

//--------------------------------------------------------------------------
//getLastName 
string Patron::getLastName() const
{
    return last;
}

//--------------------------------------------------------------------------
//getID 
int Patron::getID() const
{
    return patronID;
}

//--------------------------------------------------------------------------
//setFirstName  
void Patron::setFirstName(string name)
{
    first = name;
}

//--------------------------------------------------------------------------
//setLastName  
void Patron::setLastName(string name)
{
    last = name;
}

//--------------------------------------------------------------------------
//setID 
bool Patron::setID(int id)
{
    if (id >= 0 || id < 10000) {
        patronID = id;
        return true;
    }
    else {
        cout << "ERROR: Invalid Patron id " << id << endl;
        return false;
    }
}


//--------------------------------------------------------------------------
//setData
//reads in the file and sets transaction variables accordingly 
void Patron::setData(istream& file)
{
    string name;
    file >> name;
    this->first = name;
    file.get();

    file >> name;
    this->last = name;
}


//--------------------------------------------------------------------------
//printHistory
//used for display history of transactions 
void Patron::printHistory()
{
    for (int i = 0; i < transactions.size(); i++) {
        transactions.at(i)->print();
        cout << endl;
    }
}


//--------------------------------------------------------------------------
//addToHistory
//adds the patrons transactions to the vector 
void Patron::addToHistory(Objects* newItem, char trans)
{
    //creates respective object using the char 
    Transaction* transaction = transFactory->createObject(trans);
    (*transaction).setTransactionType(trans);
    transaction->setTransactionType(trans);
    transaction->setItem(newItem);

    transactions.push_back(transaction);
}


//--------------------------------------------------------------------------
//addToBorrowList
//adds the item to the patrons current books 
void Patron::addToBorrowList(Objects* addedItem)
{
    borrowlist.push_back(addedItem);
}

//--------------------------------------------------------------------------
//removeBorrowList
//removes the item to the patrons current books 
void Patron::removeFromBorrowList(Objects* removedItem)
{
    for (int i = 0; i < borrowlist.size(); i++) {
        if (borrowlist.at(i) == removedItem) {
            borrowlist.erase(borrowlist.begin() + i);
            break;
        }
    }
}

//--------------------------------------------------------------------------
//inCurrentBooks
//returns true if the item is in the patrons current books 
bool Patron::inCurrentBooks(const Objects& theItem)
{
    for (int i = 0; i < borrowlist.size(); i++) {
        if (*borrowlist.at(i) == theItem) {
            return true;
        }
    }
    return false;
}
