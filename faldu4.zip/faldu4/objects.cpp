#include "objects.h"

//--------------------------------------------------------------------------
//default coonstructor  
Objects::Objects()
{
    copies = 5;
}

//--------------------------------------------------------------------------
//destructor
Objects::~Objects()
{
}

//--------------------------------------------------------------------------
//getTitle
string Objects::getTitle() const
{
    return title;
}

//--------------------------------------------------------------------------
//inStock 
bool Objects::inStock() const
{
    if (copies > 0) {
        return true;
    }
    return false;
}

//--------------------------------------------------------------------------
//operator <<  
ostream& operator<<(ostream& stream, const Objects&)
{
    return stream;
}

//--------------------------------------------------------------------------
//print
void Objects::print() const
{
}

//--------------------------------------------------------------------------
//getNumCopies 
int Objects::getNumCopies() const
{
    return copies;
}

//--------------------------------------------------------------------------
//setNumCopies  
void Objects::setNumCopies(int copy)
{
    copies = copy;
}