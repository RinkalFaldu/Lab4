//---------------------------------------------------------------------------
// periodical class : derived class from book to store periodical book 
// Implementation and assumptions:  
//      this  sorted by year, then month, then title.

#ifndef PERIODICAL_H_
#define PERIODICAL_H_

#include "book.h"

class Periodical : public Book {
public:
    Periodical();
    virtual ~Periodical();
    int getMonth() const;

    void setMonth(int);

    virtual string getLastName() const;
    virtual string getFirstName() const;
    virtual Objects* create() const;
    virtual bool setData(istream&);

    virtual bool setTransactionData(istream&);
    virtual void print() const;

    virtual bool operator==(const Objects&) const;
    virtual bool operator!=(const Objects&) const;
    virtual bool operator<(const Objects&) const;
    virtual bool operator>(const Objects&) const;

protected:
    int month;       // month for periodic book 
};

#endif