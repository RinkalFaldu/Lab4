//---------------------------------------------------------------------------
// Transactionhistory class: use for printing patron's history 
//Implementation and assumptions:  
//   -- Assumed Patron exists and is in the system.

#ifndef TRANSACTION_HISTORY_H_
#define TRANSACTION_HISTORY_H_
#include "transaction.h"
class Library;
class TransactionHistory : public Transaction {
public:
    TransactionHistory();
    ~TransactionHistory();
    virtual Transaction* create() const;

    virtual bool setData(istream&);
    virtual void print() const;
    virtual bool execute(Library* lib, BinTree books[]);
};

#endif